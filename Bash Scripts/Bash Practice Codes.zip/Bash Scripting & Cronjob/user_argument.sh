#! /usr/bin/bash

#<< COMMENT
echo "please enter first number"
read number1

echo "please enter second number"
read number2

if [ "$1" == "ADD" ]; then
	echo "Your sum is: "$((number1 + number2))
elif [ "$1" == "SUB" ]; then
	echo "Your subtraction is: "$((number1 - number2))
elif [ "$1" == "DIV" ]; then
	echo "Divison of two numbers is: "$((number1 / number2))
else
	echo 'please provide valid argument'
	exit 1
fi
exit 0
#COMMENT
