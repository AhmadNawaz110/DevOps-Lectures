#! /usr/bin/cat
# #! is a shebang, tells shell which interpeter to use
# is a utility/program to be used


echo "Hello dear students!" 
